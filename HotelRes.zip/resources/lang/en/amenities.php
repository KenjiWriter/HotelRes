<?php

return [
    'WiFi' => 'WiFi',
    'Separate_kitchen' => 'Separate Kitchen',
    'Bathtub' => 'Bathtub',
    'Jacuzzi' => 'Jacuzzi',
    'Balcony' => 'Balcony',
    'Television' => 'Television',
    'Air_conditioning' => 'Air Conditioning',
    'Safe' => 'Safe',
    'Mini_bar' => 'Mini Bar',
    'Room_service' => 'Room Service',
    'Parking' => 'Parking',
    'Swimming_pool' => 'Swimming Pool',
    'Gym' => 'Gym',
    'Spa' => 'Spa',
    'Amenities' => 'Amenities',
    'Select' => 'Select',
];