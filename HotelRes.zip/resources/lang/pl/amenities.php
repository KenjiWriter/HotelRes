<?php

return [
    'WiFi' => 'WiFi',
    'Separate_kitchen' => 'Oddzielna kuchnia',
    'Bathtub' => 'Wanna',
    'Jacuzzi' => 'Wanna z hydromasażem',
    'Balcony' => 'Balkon',
    'Television' => 'Telewizor',
    'Air_conditioning' => 'Klimatyzacja',
    'Safe' => 'Sejf',
    'Mini_bar' => 'Mini-bar',
    'Room_service' => 'Room service',
    'Parking' => 'Parking',
    'Swimming_pool' => 'Basen',
    'Gym' => 'Siłownia',
    'Spa' => 'Spa',
    'Amenities' => 'Udogodeninia',
    'Select' => 'Wybierz',
];