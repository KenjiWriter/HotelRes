<?php return array (
  'room-search' => 'App\\Http\\Livewire\\RoomSearch',
  'search-results' => 'App\\Http\\Livewire\\SearchResults',
);