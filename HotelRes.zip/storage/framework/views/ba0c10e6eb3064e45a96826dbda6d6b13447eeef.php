
<?php $__env->startSection('title', __('messages.room_name', ['name' => $room->name])); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .swiper-container {
            width: 100%;
            height: 256px;
        }
        .swiper-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .swiper-button-next, .swiper-button-prev {
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            padding: 30px 20px;
            border-radius: 5px;
        }
        .swiper-button-next:after, .swiper-button-prev:after {
            font-size: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-8 dark:text-white"><?php echo e($room->name); ?></h1>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <strong class="font-bold"><?php echo e(__('messages.error')); ?></strong>
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <!-- Section with images and description -->
        <div class="bg-white shadow-md rounded-lg overflow-hidden mb-8 flex dark:bg-gray-800">
            <!-- Images on the left -->
            <div class="w-1/2">
                <div class="swiper-container h-64 relative">
                    <div class="swiper-wrapper">
                        <?php if($room->images->isEmpty()): ?>
                            <div class="swiper-slide">
                                <img src="<?php echo e(asset('rooms_photos/room1.png')); ?>" alt="<?php echo e($room->name); ?>" class="w-full h-full object-cover">
                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = $room->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <img src="<?php echo e(asset($image->image_path)); ?>" alt="<?php echo e($room->name); ?>" class="w-full h-full object-cover">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="absolute bottom-0 right-0 bg-black bg-opacity-50 text-white px-2 py-1 text-sm dark:text-white">
                        <?php echo e(__('messages.swipe_to_see_more')); ?>

                    </div>
                </div>
            </div>

            <!-- Description on the right -->
            <div class="w-1/2 p-6">
                <p class="text-gray-700 mb-4 dark:text-white"><?php echo e($room->description); ?></p>
                <p class="text-lg font-semibold mb-2 dark:text-white"><?php echo e(__('messages.price')); ?>: <?php echo e(number_format($room->price_per_person, 2)); ?> <?php echo e(__('messages.per_person_per_night')); ?></p>
                <p class="text-gray-600 mb-4 dark:text-white"><?php echo e(__('messages.capacity')); ?>: <?php echo e($room->capacity); ?></p>
                <!-- Amenities -->
                <h3 class="text-lg font-bold mt-4 dark:text-white"><?php echo e(__('amenities.Amenities')); ?>:</h3>
                <ul class="list-disc list-inside dark:text-white">
                    <?php $__currentLoopData = $room->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e(__('amenities.' . $amenity->name)); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <h2 class="text-2xl font-bold mb-4"><?php echo e(__('messages.booking_room')); ?></h2>
        <form action="<?php echo e(route('room.reserve', $room->id)); ?>" method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 dark:bg-gray-800">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2 dark:text-white" for="guest_name">
                    <?php echo e(__('messages.guest_name')); ?>

                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline dark:text-gray-300 dark:bg-gray-700" id="guest_name" type="text" name="guest_name" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2 dark:text-white" for="guest_email">
                    <?php echo e(__('messages.guest_email')); ?>

                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline dark:text-gray-300 dark:bg-gray-700" id="guest_email" type="email" name="guest_email" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2 dark:text-white" for="check_in">
                    <?php echo e(__('messages.check_in')); ?>

                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline dark:text-gray-300 dark:bg-gray-700" id="check_in" type="date" name="check_in" value="<?php echo e($checkIn ? $checkIn->format('Y-m-d') : ''); ?>" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2 dark:text-white" for="check_out">
                    <?php echo e(__('messages.check_out')); ?>

                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline dark:text-gray-300 dark:bg-gray-700" id="check_out" type="date" name="check_out" value="<?php echo e($checkOut ? $checkOut->format('Y-m-d') : ''); ?>" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2 dark:text-white" for="guests_number">
                    <?php echo e(__('messages.guests_number')); ?>

                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline dark:text-gray-300 dark:bg-gray-700" id="guests_number" type="number" name="guests_number" min="1" max="<?php echo e($room->capacity); ?>" value="1" required>
            </div>
            <div class="mb-6">
                <p class="text-lg font-bold"><?php echo e(__('messages.total_price')); ?>: <span id="total_price">0.00</span> PLN</p>
            </div>
            <div class="flex items-center justify-between">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                    <?php echo e(__('messages.reserve')); ?>

                </button>
            </div>
        </form>
        <div class="mt-8">
            <h3 class="text-xl font-bold mb-4">Average Rating: <?php echo e(number_format($room->averageRating(), 1)); ?></h3>
        
            <?php $__currentLoopData = $room->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-4 p-4 bg-gray-100 dark:bg-gray-800 rounded">
                    <p><strong>Rating:</strong> <?php echo e(number_format($review->rating, 1)); ?></p>
                    <?php if($review->comment): ?>
                        <p><strong>Comment:</strong> <?php echo e($review->comment); ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const checkInInput = document.getElementById('check_in');
            const checkOutInput = document.getElementById('check_out');
            const guestsNumberInput = document.getElementById('guests_number');
            const totalPriceSpan = document.getElementById('total_price');
            const pricePerPerson = <?php echo e($room->price_per_person); ?>;

            function calculateTotalPrice() {
                const checkIn = new Date(checkInInput.value);
                const checkOut = new Date(checkOutInput.value);
                const guestsNumber = parseInt(guestsNumberInput.value) || 1;

                if (checkIn && checkOut && checkOut > checkIn) {
                    const nights = (checkOut - checkIn) / (1000 * 60 * 60 * 24);
                    const totalPrice = pricePerPerson * guestsNumber * nights;
                    totalPriceSpan.textContent = totalPrice.toFixed(2);
                } else {
                    totalPriceSpan.textContent = '0.00';
                }
            }

            checkInInput.addEventListener('change', calculateTotalPrice);
            checkOutInput.addEventListener('change', calculateTotalPrice);
            guestsNumberInput.addEventListener('input', calculateTotalPrice);

            // Oblicz cenę przy ładowaniu strony
            calculateTotalPrice();
        });
        new Swiper('.swiper-container', {
            loop: true,
            pagination: {
                el: '.swiper-pagination',
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            spaceBetween: 4000,
            slidesPerView: 1,
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\HotelRes\resources\views/rooms/show.blade.php ENDPATH**/ ?>