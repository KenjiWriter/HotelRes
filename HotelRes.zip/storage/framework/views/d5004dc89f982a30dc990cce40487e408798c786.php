<div>
    <?php if($errorMessage): ?>
        <div x-data="{ show: true }" x-show.transition.opacity.out.duration.1500ms.delay.500ms="show" x-init="setTimeout(() => show = false, 5000)" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
            <?php echo e($errorMessage); ?>

            <span @click="show = false" class="absolute top-0 bottom-0 right-0 px-4 py-3 cursor-pointer">×</span>
        </div>
    <?php endif; ?>  
    <form class="bg-white dark:bg-gray-800 shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="check_in">
                <?php echo e(__('messages.check_in')); ?>

            </label>
            <input wire:model="checkIn" type="date" id="check_in" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-300 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline">
        </div>
        
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="check_out">
                <?php echo e(__('messages.check_out')); ?>

            </label>
            <input wire:model="checkOut" type="date" id="check_out" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-300 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="guests">
                <?php echo e(__('messages.guests')); ?>

            </label>
            <input wire:model="guests" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-300 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="guests" type="number" name="guests" min="1" required>
        </div>
        <div class="mb-4 flex space-x-4">
            <div class="w-1/2">
                <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="price_min">
                    <?php echo e(__('messages.price_min')); ?>

                </label>
                <input wire:model="priceMin" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-300 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="price_min" type="number" name="price_min" min="0" step="0.01">
            </div>
            <div class="w-1/2">
                <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="price_max">
                    <?php echo e(__('messages.price_max')); ?>

                </label>
                <input wire:model="priceMax" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-300 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="price_max" type="number" name="price_max" min="0" step="0.01">
            </div>
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" for="amenities">
                <?php echo e(__('amenities.Amenities')); ?>

            </label>
            <div class="relative">
                <button type="button" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-300 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" onclick="toggleDropdown()">
                    <?php echo e(__('amenities.Select')); ?> <?php echo e(__('amenities.Amenities')); ?>

                </button>
                <div id="dropdown" class="absolute mt-1 w-full bg-white dark:bg-gray-900 shadow-md rounded hidden z-50 transition-all duration-300 ease-in-out transform opacity-0 scale-y-0 origin-top" wire:ignore>
                    <?php $__currentLoopData = App\Models\Amenity::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800">
                            <input type="checkbox" value="<?php echo e($amenity->id); ?>" class="mr-2" onchange="updateAmenities()">
                            <?php echo e(__('amenities.' . $amenity->name)); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="flex items-center justify-between">
            <button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" wire:click="search">
                <?php echo e(__('messages.search')); ?> (<?php echo e($availableRoomsCount); ?>)
            </button>
        </div>
    </form>

    <script>
        function updateAmenities() {
            const checkboxes = document.querySelectorAll('#dropdown input[type="checkbox"]');
            const selectedAmenities = Array.from(checkboxes)
                .filter(checkbox => checkbox.checked)
                .map(checkbox => checkbox.value);

            window.livewire.find('<?php echo e($_instance->id); ?>').set('amenities', selectedAmenities);
        }
    </script>
</div><?php /**PATH D:\dev\HotelRes\resources\views/livewire/room-search.blade.php ENDPATH**/ ?>