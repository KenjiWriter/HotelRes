
<?php $__env->startSection('title', __('messages.confirmation_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-8 dark:text-white"><?php echo e(__('messages.confirmation_title')); ?></h1>

        <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden mb-8">
            <div class="p-6">
                <h2 class="text-2xl font-bold mb-4 dark:text-white"><?php echo e(__('messages.reservation_details')); ?></h2>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.room')); ?>:</strong> <?php echo e($reservation->room->name); ?></p>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.guest')); ?>:</strong> <?php echo e($reservation->guest_name); ?></p>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.email')); ?>:</strong> <?php echo e($reservation->guest_email); ?></p>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.check_in')); ?>:</strong> <?php echo e($reservation->check_in->format('d.m.Y')); ?></p>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.check_out')); ?>:</strong> <?php echo e($reservation->check_out->format('d.m.Y')); ?></p>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.guests_number')); ?>:</strong> <?php echo e($reservation->guests_number); ?></p>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.per_person_per_night')); ?>:</strong> <?php echo e(number_format($reservation->room->price_per_person, 2)); ?> PLN</p>
                <p class="dark:text-gray-300"><strong><?php echo e(__('messages.total_price')); ?>:</strong> <?php echo e(number_format($reservation->total_price, 2)); ?> PLN</p>
            </div>
        </div>

        <a href="<?php echo e(route('home')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            <?php echo e(__('messages.back_to_home')); ?>

        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\HotelRes\resources\views/reservations/confirmation.blade.php ENDPATH**/ ?>