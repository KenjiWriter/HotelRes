
<?php $__env->startSection('title', __('messages.search_room')); ?>
<?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-8 dark:text-white"><?php echo e(__('messages.search_room')); ?></h1>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('room-search')->html();
} elseif ($_instance->childHasBeenRendered('5DQ4k0z')) {
    $componentId = $_instance->getRenderedChildComponentId('5DQ4k0z');
    $componentTag = $_instance->getRenderedChildComponentTagName('5DQ4k0z');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5DQ4k0z');
} else {
    $response = \Livewire\Livewire::mount('room-search');
    $html = $response->html();
    $_instance->logRenderedChild('5DQ4k0z', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <h2 class="text-2xl font-bold mb-4 dark:text-white"><?php echo e(__('messages.suggested_rooms')); ?></h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $suggestedRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
                <div class="swiper-container h-64 relative">
                    <div class="swiper-wrapper">
                        <?php if($room->images->isEmpty()): ?>
                            <div class="swiper-slide">
                                <img src="<?php echo e(asset('rooms_photos/room1.png')); ?>" alt="<?php echo e($room->name); ?>" class="w-full h-full object-cover">
                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = $room->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <img src="<?php echo e(asset($image->image_path)); ?>" alt="<?php echo e($room->name); ?>" class="w-full h-full object-cover">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="absolute bottom-0 right-0 bg-black bg-opacity-50 text-white px-2 py-1 text-sm">
                        <?php echo e(__('messages.swipe_to_see_more')); ?>

                    </div>
                </div>
                <div class="p-6">
                    <h2 class="text-xl font-bold mb-2 dark:text-white"><?php echo e($room->name); ?></h2>
                    <p class="text-gray-700 dark:text-gray-300 mb-4"><?php echo e(Str::limit($room->description, 100)); ?></p>
                    <p class="text-lg font-semibold dark:text-gray-300"><?php echo e(__('messages.price')); ?>: <?php echo e(number_format($room->price_per_person, 2)); ?> <?php echo e(__('messages.per_person_per_night')); ?></p>
                    <p class="text-gray-600 mb-4 dark:text-white"><?php echo e(__('messages.capacity')); ?>: <?php echo e($room->capacity); ?></p>
                    <a href="<?php echo e(route('room.show', ['id' => $room->id])); ?>"
                       class="mt-4 inline-block bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                       <?php echo e(__('messages.details_and_booking')); ?>

                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            dropdown.classList.toggle('hidden');
            dropdown.classList.toggle('opacity-0');
            dropdown.classList.toggle('scale-y-0');
        }

        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('dropdown');
            if (!event.target.closest('#dropdown') && !event.target.closest('button')) {
                dropdown.classList.add('hidden');
                dropdown.classList.add('opacity-0');
                dropdown.classList.add('scale-y-0');
            }
        });

        document.querySelectorAll('#dropdown input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('click', function(event) {
                event.stopPropagation();
            });
        });

        new Swiper('.swiper-container', {
            loop: true,
            pagination: {
                el: '.swiper-pagination',
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            spaceBetween: 4000,
            slidesPerView: 1,
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\HotelRes\resources\views\home.blade.php ENDPATH**/ ?>