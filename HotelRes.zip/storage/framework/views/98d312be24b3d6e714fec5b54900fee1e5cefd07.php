
<?php $__env->startSection('title', __('messages.search_results')); ?>
<?php echo \Livewire\Livewire::styles(); ?>


<?php $__env->startSection('style'); ?>
    <style>
        .swiper-container {
            width: 100%;
            height: 256px;
        }
        .swiper-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .swiper-button-next, .swiper-button-prev {
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            padding: 30px 20px;
            border-radius: 5px;
        }
        .swiper-button-next:after, .swiper-button-prev:after {
            font-size: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-8 dark:text-white"><?php echo e(__('messages.search_results')); ?></h1>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-results', ['rooms' => $rooms, 'checkIn' => $checkIn, 'checkOut' => $checkOut])->html();
} elseif ($_instance->childHasBeenRendered('tLHYMYj')) {
    $componentId = $_instance->getRenderedChildComponentId('tLHYMYj');
    $componentTag = $_instance->getRenderedChildComponentTagName('tLHYMYj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tLHYMYj');
} else {
    $response = \Livewire\Livewire::mount('search-results', ['rooms' => $rooms, 'checkIn' => $checkIn, 'checkOut' => $checkOut]);
    $html = $response->html();
    $_instance->logRenderedChild('tLHYMYj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\HotelRes\resources\views\search_results.blade.php ENDPATH**/ ?>