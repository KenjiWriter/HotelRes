

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-8">Rate Your Stay</h1>

    <form action="<?php echo e(route('review.store')); ?>" method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="room_id" value="<?php echo e($room->id); ?>">
        <input type="hidden" name="reservation_id" value="<?php echo e($reservation->id); ?>">

        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="rating">
                Rating (1.0 - 5.0)
            </label>
            <select name="rating" id="rating" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                <?php for($i = 1; $i <= 5; $i += 0.5): ?>
                    <option value="<?php echo e(number_format($i, 1)); ?>"><?php echo e(number_format($i, 1)); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="comment">
                Comment
            </label>
            <textarea name="comment" id="comment" rows="4" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
        </div>

        <div class="flex items-center justify-between">
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                Submit Review
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\HotelRes\resources\views/reviews/create.blade.php ENDPATH**/ ?>