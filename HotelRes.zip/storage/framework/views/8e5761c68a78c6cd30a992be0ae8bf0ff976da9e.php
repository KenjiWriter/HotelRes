<div>
    <style>
        .swiper-container {
            width: 100%;
            height: 256px;
        }
        .swiper-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .swiper-button-next, .swiper-button-prev {
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            padding: 30px 20px;
            border-radius: 5px;
        }
        .swiper-button-next:after, .swiper-button-prev:after {
            font-size: 20px;
        }
    </style>

    <div class="mb-4">
        <label for="sortOrder" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">
            <?php echo e(__('messages.sort_by_price')); ?>

        </label>
        <select wire:model="sortOrder" id="sortOrder" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-300 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline">
            <option value="default"><?php echo e(__('messages.default_order')); ?></option>
            <option value="asc"><?php echo e(__('messages.price_ascending')); ?></option>
            <option value="desc"><?php echo e(__('messages.price_descending')); ?></option>
        </select>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
                <div class="swiper-container h-64 relative">
                    <div class="swiper-wrapper">
                        <?php if($room->images->isEmpty()): ?>
                            <div class="swiper-slide">
                                <img src="<?php echo e(asset('rooms_photos/room1.png')); ?>" alt="<?php echo e($room->name); ?>" class="w-full h-full object-cover">
                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = $room->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <img src="<?php echo e(asset($image->image_path)); ?>" alt="<?php echo e($room->name); ?>" class="w-full h-full object-cover">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="absolute bottom-0 right-0 bg-black bg-opacity-50 text-white px-2 py-1 text-sm">
                        <?php echo e(__('messages.swipe_to_see_more')); ?>

                    </div>
                </div>
                <div class="p-6">
                    <h2 class="text-xl font-bold mb-2 dark:text-white"><?php echo e($room->name); ?></h2>
                    <p class="text-gray-700 dark:text-gray-300 mb-4"><?php echo e(Str::limit($room->description, 100)); ?></p>
                    <p class="text-lg font-semibold dark:text-gray-300"><?php echo e(__('messages.price')); ?>: <?php echo e(number_format($room->price_per_person, 2)); ?> <?php echo e(__('messages.per_person_per_night')); ?></p>
                    <p class="text-gray-600 mb-4 dark:text-white"><?php echo e(__('messages.capacity')); ?>: <?php echo e($room->capacity); ?></p>
                    <p class="font-bold mb-4 text-gray-600 dark:text-white">Average Rating: <?php echo e(number_format($room->averageRating(), 1)); ?></p>
                    <a href="<?php echo e(route('room.show', ['id' => $room->id, 'check_in' => $checkIn->format('Y-m-d'), 'check_out' => $checkOut->format('Y-m-d')])); ?>"
                    class="mt-4 inline-block bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    <?php echo e(__('messages.details_and_booking')); ?>

                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <script>
        // Initialize Swiper
        document.querySelectorAll('.swiper-container').forEach(container => {
            const swiperWrapper = container.querySelector('.swiper-wrapper');
            const slidesCount = swiperWrapper.children.length;

            new Swiper(container, {
                loop: slidesCount > 1,
                pagination: {
                    el: '.swiper-pagination',
                },
                navigation: slidesCount > 1 ? {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                } : false,
            });
        });
    </script>
</div><?php /**PATH D:\dev\HotelRes\resources\views/livewire/search-results.blade.php ENDPATH**/ ?>